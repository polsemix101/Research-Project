"""
Function Library for Marwan et al QSR 2021

Recurrence Quantification Analysis
Recurrence Networks Analysis
Potential Analysis
Entropy Analysis
Irreversibility Test of Visibility Graph

implemented by Deniz Eroglu (KH Univ Istanbul)
"""

##########################################################################
# Imports
##########################################################################

from itertools import permutations
import numpy as np
import scipy.stats
from scipy.stats.kde import gaussian_kde
from scipy.signal import qmf
from scipy.stats.stats import linregress
from scipy.special import gamma
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt
from collections import defaultdict


##########################################################################
# To find the indice of the value or values
##########################################################################
def indices(a, func):
    return [i for (i, val) in enumerate(a) if func(val)]


##########################################################################
# Embedding
##########################################################################
def embed_ts(time_series, dim, tau):
    dim = int(dim)
    tau = int(tau)

    n_time = time_series.shape[0]
    embedding = np.empty((n_time - (dim - 1) * tau, dim), dtype="float32")

    max_delay = (dim - 1) * tau
    len_embedded = n_time - max_delay

    for j in range(dim):
        index = j*tau
        for k in range(len_embedded):
            embedding[k,j] = time_series[index]
            index += 1

    return embedding


##########################################################################
# Permutations, Ordering etc.
# For symbolic dynamics
##########################################################################


def find_permutations(z,d):
    z = z.astype(int)
    digits = np.chararray(len(z),itemsize=3)
    for i in range(len(z)):
        ch = ''
        for j in range(d):
            ch = ch + str(z[i,j])
            digits[i] = ch
    digits = map(int, digits)
    return sorted(digits)

def order(x):
    try:
        t , n  = x.shape
        orderPattern = np.zeros([t,n])
        for j in range(t):
            orderPattern[j,:] = [i[0] for i in sorted(enumerate(x[j,:]), key=lambda x:x[1])]
        return  orderPattern+1
    except:
        return  [i[0] for i in sorted(enumerate(x), key=lambda x:x[1])]


##########################################################################
# Entropy Measures
##########################################################################

# Create pdf for shannon entropy
def shannonEntropy(x,bins=100,cov_fac = 0.25):
    kde = gaussian_kde(x)
    kde.covariance_factor = lambda : cov_fac
    dist_space = np.linspace(min(x), max(x), bins)
    pdf = kde(dist_space)
    pdf = np.extract(pdf != 0, pdf)
    return shannonEnt(pdf)

# Shannon Entropy
def shannonEnt(pdf):
    np.extract(pdf != 0, pdf)
    diagnorm = pdf / float(pdf.sum())
    return -(diagnorm * np.log(diagnorm)).sum()


# Create pdf for symbolic dynamics
def symbolicPerm(x,d,t):
    x = embed_ts(x,d,t)
    x = order(x)
    x = find_permutations(x,d)
    return x

# Symbolic entropy
def symbolicEntropy(x):
    y = dict((i, x.count(i)) for i in x)
    pdf = np.array(list(y.values()))
    return shannonEnt(pdf)


##########################################################################
# Potential Analysis
##########################################################################
def potential(x, sigma, cov_fac = 0.25):
    kde = gaussian_kde(x)
    kde.covariance_factor = lambda : cov_fac
    dist_space = np.linspace(min(x), max(x), 100)
    U = -(np.power(sigma,2)/2)*np.log(kde(dist_space))
    pot = 0
    for j in range(1,len(U)-1):
        if(U[j] < U[j-1] and U[j] < U[j+1]):
            pot += 1
    return pot


##########################################################################
# Significance Analysis
##########################################################################

## Recurrence Plot (Marwan - EPL - 2013)
def get_determinism(diagline, l_min=2):

    n_time = len(diagline)

    #  Number of recurrence points that form diagonal structures (of at
    #  least length l_min)
    partial_sum = (np.arange(l_min,n_time) * diagline[l_min:]).sum()

    #  Number of all recurrence points that form diagonal lines (except
    #  the main diagonal)
    full_sum = (np.arange(n_time) * diagline).sum()

    return partial_sum / float(full_sum)


def get_laminarity(vertline, v_min=2):

    n_time = len(vertline)

    #  Number of recurrence points that form vertical structures (of at
    #  least length v_min)
    partial_sum = (np.arange(v_min,n_time) * vertline[v_min:]).sum()

    #  Number of all recurrence points that form vertical lines
    full_sum = (np.arange(n_time) * vertline).sum()

    return partial_sum / float(full_sum)


def rp_significance(P, n, measure, nofexp = 500):
    x = np.zeros(nofexp)
    cdf = np.cumsum(P)
    cdf = cdf / cdf[-1] +0.0
    for i in range(nofexp):
        values = np.random.rand(n)
        value_bins = np.searchsorted(cdf, values)
        d=defaultdict(int)
        #a = map(int,[x**0.5 for x in range(20)])
        for j in value_bins:
            d[j]+=1
        y = max(d.keys())
        z = np.zeros(y+1)
        for k, v in d.items():
            z[k] = v
        if (measure == 'determinism'):
            x[i] = get_determinism(z)
        if measure == 'laminarity':
            x[i] = get_laminarity(z)
        if (measure == 'tt'):
            x[i] = get_average_vertlength(z)
        del d, z
    return significance(x)

def block_significance(x, n, nofexp = 500):
    ent = np.zeros(nofexp)
    x = dict((i, x.count(i)) for i in x)
    P = np.array(list(x.values()))
    cdf = np.cumsum(P)+ 0.0
    cdf = cdf / cdf[-1]

    for i in range(nofexp):
        values = np.random.rand(n)
        value_bins = np.searchsorted(cdf, values)
        d=defaultdict(int)
        for j in value_bins:
            d[j]+=1
        z = np.array(list(d.values()))
        ent[i] = shannonEnt(z)

    return significance(ent)

def significance(x, confInt_l = 0.05, confInt_r = 0.95 ):
    hist, bins = np.histogram(x, bins=100)
    cdf = np.cumsum(hist)
    cdf = cdf / float(cdf[-1])
    ind = indices(cdf, lambda x: x > confInt_l)
    left = bins[ind[0]]
    ind = indices(cdf, lambda x: x < confInt_r)
    right = bins[ind[-1]]
    return left, right


