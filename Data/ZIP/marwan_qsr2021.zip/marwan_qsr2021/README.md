# Nonlinear time series analysis of palaeoclimate proxy records

_by Norbert Marwan, Jonathan F. Donges, Deniz Eroglu, published in Quaternary Science Reviews, 2021_

Jupyter notebook (`marwan_qsr2021.ipynb`) for nonlinear time series analysis of the palaeoclimate proxy records used in the paper. It calculates the number of potential wells $n_u$, the entropy of the data $S$, the order pattern (permutation) entropy $S_{order}$, the recurrence quantification/network measures $DET$, $LAM$, $\mathcal{T}$, and $\mathcal{L}$ as well as the visibility graph based irreversibility test statsitics $p(k)$ and $p(\mathcal{C})$.

The data file can be simply exchanged by own data file.

The file `nonlinear_timeseries_analysis.py` contains the routines for the single time series analysis methods and should be in the same folder as the Jupyter notebook. It can not be executed by itself. It is called from within the Jupyter notebook.

The repository also contains the data sets used in the analysis in the folder `Data`.